export class MIDI {
    constructor() {
        this.audioContext = null;
        this.activeNotes = new Map(); // MIDI note -> {oscillator, gainNode, button}
        this.isSequencePlaying = false;
    }

        // MIDI note to frequency conversion
    midiToFreq(midiNote) {
        return 440 * Math.pow(2, (midiNote - 69) / 12);
    }

        // Get note name from MIDI number
    midiToNoteName(midiNote) {
        const noteNames = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
        const octave = Math.floor(midiNote / 12) - 1;
        const noteName = noteNames[midiNote % 12];
        return `${noteName}${octave}`;
    }

        // Initialize audio context
    async initAudio() {
        if (!this.audioContext) {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        }
        if (this.audioContext.state === 'suspended') {
            await this.audioContext.resume();
        }
    }

        // Start playing a sustained note
    async startNote(midiNote, velocity = 100) {
        try {
            await this.initAudio();
            
            console.log('starting')
            // Don't start if already playing
            if (this.activeNotes.has(midiNote)) return;
            
            // Create oscillator and gain
            const oscillator = this.audioContext.createOscillator();
            const gainNode = this.audioContext.createGain();
            
            // Connect audio graph
            oscillator.connect(gainNode);
            gainNode.connect(this.audioContext.destination);
            
            // Set frequency from MIDI note
            const frequency = this.midiToFreq(midiNote);
            oscillator.frequency.setValueAtTime(frequency, this.audioContext.currentTime);
            oscillator.type = 'sine';
            
            // Set volume from MIDI velocity (0-127 -> 0-0.3)
            const volume = (velocity / 127) * 0.3;
            gainNode.gain.setValueAtTime(0, this.audioContext.currentTime);
            gainNode.gain.linearRampToValueAtTime(volume, this.audioContext.currentTime + 0.01);
            
            // Start the oscillator (plays indefinitely)
            oscillator.start(this.audioContext.currentTime);
            
            // Store in active notes
            this.activeNotes.set(midiNote, {oscillator, gainNode});
            
            console.log(`Started note: ${midiNote} (${this.midiToNoteName(midiNote)})`);
            
        } catch (error) {
            console.error('Audio error:', error);
        }
    }

        // Stop playing a sustained note
    stopNote(midiNote) {
        if (!this.activeNotes.has(midiNote)) return;
        
        const noteData = this.activeNotes.get(midiNote);
        
        // Fade out and stop
        noteData.gainNode.gain.linearRampToValueAtTime(0, this.audioContext.currentTime + 0.01);
        noteData.oscillator.stop(this.audioContext.currentTime + 0.02);

        // Remove from active notes
        this.activeNotes.delete(midiNote);

        console.log(`Stopped note: ${midiNote} (${this.midiToNoteName(midiNote)})`);
    }

        // Toggle note on/off
    toggleNote(midiNote) {
        if (this.activeNotes.has(midiNote)) {
            this.stopNote(midiNote);
        } else {
            this.startNote(midiNote);
        }
    }

        // Play a chord (array of MIDI notes)
    playChord(midiNotes) {
        // Stop current chord first
        this.stopAll();
        
        // Start all notes in the chord
        setTimeout(() => {
            midiNotes.forEach(note => this.startNote(note));
        }, 50);
    }

        // Stop all playing notes
    stopAll() {
        const notesToStop = Array.from(this.activeNotes.keys());
        notesToStop.forEach(midiNote => this.stopNote(midiNote));
        this.isSequencePlaying = false;
        console.log('All notes stopped');
    }

    // Play a note with instrument ID and duration
    // Instruments:
    // 0 - flute
    // 1 - clarinet
    // 2 - trumpet
    // 3 - recorder
    async playNoteWithInstrument(pitch, instrumentId = 0, durationMs = 500, velocity = 100) {
        try {
            await this.initAudio();

            // Instrument ID to oscillator type mapping
            const instrumentMap = ['sine', 'square', 'sawtooth', 'triangle'];
            const type = instrumentMap[instrumentId % instrumentMap.length];

            const frequency = this.midiToFreq(pitch);
            const oscillator = this.audioContext.createOscillator();
            const gainNode = this.audioContext.createGain();

            oscillator.type = type;
            oscillator.frequency.setValueAtTime(frequency, this.audioContext.currentTime);

            const volume = (velocity / 127) * 0.3;
            gainNode.gain.setValueAtTime(0, this.audioContext.currentTime);
            gainNode.gain.linearRampToValueAtTime(volume, this.audioContext.currentTime + 0.01);

            oscillator.connect(gainNode);
            gainNode.connect(this.audioContext.destination);

            oscillator.start(this.audioContext.currentTime);

            // Schedule stop
            gainNode.gain.linearRampToValueAtTime(0, this.audioContext.currentTime + durationMs / 1000);
            oscillator.stop(this.audioContext.currentTime + durationMs / 1000 + 0.02);

            console.log(`Played note: ${pitch} (${this.midiToNoteName(pitch)}), Instrument: ${type}, Duration: ${durationMs}ms`);
        } catch (error) {
            console.error('Audio error in playNoteWithInstrument:', error);
        }
    }
}